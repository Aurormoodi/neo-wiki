# Wiki-Artikel

Artikel liegen in der ersten Version zentral in `script.js`. Bei größerem Umfang können sie in einzelne JSON-Dateien ausgelagert werden.
